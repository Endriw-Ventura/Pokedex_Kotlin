package com.example.pokedex.data.responses

data class Versions(
    val generation-i: GenerationI,
    val generation-ii: GenerationIi,
    val generation-iii: GenerationIii,
    val generation-iv: GenerationIv,
    val generation-v: GenerationV,
    val generation-vi: GenerationVi,
    val generation-vii: GenerationVii,
    val generation-viii: GenerationViii
)