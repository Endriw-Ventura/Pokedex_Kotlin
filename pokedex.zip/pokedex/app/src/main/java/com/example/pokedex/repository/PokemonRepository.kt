package com.example.pokedex.repository

import com.example.pokedex.data.remote.PokeApi
import com.example.pokedex.data.responses.PokemonData
import com.example.pokedex.data.responses.PokemonList
import com.example.pokedex.util.Resource

class PokemonRepository(
    private val api: PokeApi
) {

    suspend fun getPokemonList(limit: Int, offset:Int): Resource<PokemonList> {
        val response = try {
            api.getPokemonList(limit, offset)
        }catch(e: Exception) {
            return Resource.Error(message = "Error Occurred")
        }
        return Resource.Success(response)
    }

    suspend fun getPokemonInfo(pokemonName: String): Resource<PokemonData> {
        val response = try {
            api.getPokemonInfo(pokemonName)
        }catch(e: Exception) {
            return Resource.Error(message = "Error Occurred")
        }
        return Resource.Success(response)
    }
}