package com.example.pokedex.data.responses

data class MoveX(
    val name: String,
    val url: String
)