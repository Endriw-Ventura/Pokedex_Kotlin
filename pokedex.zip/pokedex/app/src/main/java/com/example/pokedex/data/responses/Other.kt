package com.example.pokedex.data.responses

data class Other(
    val dream_world: DreamWorld,
    val home: Home,
    val official-artwork: OfficialArtwork
)