package com.example.pokedex.data.responses

data class OfficialArtwork(
    val front_default: String,
    val front_shiny: String
)