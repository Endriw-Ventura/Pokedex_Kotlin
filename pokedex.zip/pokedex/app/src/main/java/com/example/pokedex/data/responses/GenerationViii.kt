package com.example.pokedex.data.responses

data class GenerationViii(
    val icons: Icons
)