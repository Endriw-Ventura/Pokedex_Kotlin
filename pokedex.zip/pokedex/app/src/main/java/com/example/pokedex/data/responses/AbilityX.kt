package com.example.pokedex.data.responses

data class AbilityX(
    val name: String,
    val url: String
)