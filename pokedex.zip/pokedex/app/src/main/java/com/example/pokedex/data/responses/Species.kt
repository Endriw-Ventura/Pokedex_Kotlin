package com.example.pokedex.data.responses

data class Species(
    val name: String,
    val url: String
)