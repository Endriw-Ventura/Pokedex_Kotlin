package com.example.pokedex.data.responses

data class GameIndice(
    val game_index: Int,
    val version: Version
)