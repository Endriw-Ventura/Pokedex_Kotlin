package com.example.pokedex.data.responses

data class GenerationIi(
    val crystal: Crystal,
    val gold: Gold,
    val silver: Silver
)