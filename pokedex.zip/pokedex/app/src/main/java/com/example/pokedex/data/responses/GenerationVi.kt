package com.example.pokedex.data.responses

data class GenerationVi(
    val omegaruby-alphasapphire: OmegarubyAlphasapphire,
    val x-y: XY
)