package com.example.pokedex.data.responses

data class TypeX(
    val name: String,
    val url: String
)