package com.example.pokedex.data.responses

data class GenerationIii(
    val emerald: Emerald,
    val firered-leafgreen: FireredLeafgreen,
    val ruby-sapphire: RubySapphire
)