package com.example.pokedex.data.responses

data class Stat(
    val base_stat: Int,
    val effort: Int,
    val stat: StatX
)