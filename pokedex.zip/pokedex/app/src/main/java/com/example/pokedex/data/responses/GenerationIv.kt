package com.example.pokedex.data.responses

data class GenerationIv(
    val diamond-pearl: DiamondPearl,
    val heartgold-soulsilver: HeartgoldSoulsilver,
    val platinum: Platinum
)