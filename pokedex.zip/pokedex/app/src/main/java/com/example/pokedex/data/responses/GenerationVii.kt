package com.example.pokedex.data.responses

data class GenerationVii(
    val icons: Icons,
    val ultra-sun-ultra-moon: UltraSunUltraMoon
)