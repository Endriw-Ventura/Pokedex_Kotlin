package com.example.pokedex.data.responses

data class GenerationI(
    val red-blue: RedBlue,
    val yellow: Yellow
)