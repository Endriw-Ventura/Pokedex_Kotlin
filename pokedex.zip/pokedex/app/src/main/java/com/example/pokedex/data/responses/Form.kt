package com.example.pokedex.data.responses

data class Form(
    val name: String,
    val url: String
)