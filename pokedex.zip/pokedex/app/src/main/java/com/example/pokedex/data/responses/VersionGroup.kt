package com.example.pokedex.data.responses

data class VersionGroup(
    val name: String,
    val url: String
)