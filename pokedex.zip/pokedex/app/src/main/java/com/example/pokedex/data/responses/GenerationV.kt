package com.example.pokedex.data.responses

data class GenerationV(
    val black-white: BlackWhite
)