package com.example.pokedex.data.responses

data class MoveLearnMethod(
    val name: String,
    val url: String
)