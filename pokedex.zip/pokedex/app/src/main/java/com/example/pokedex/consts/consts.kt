package com.example.pokedex.consts

object consts {
    const val BASE_URL = "https://pokeapi.co/api/v2/"
}