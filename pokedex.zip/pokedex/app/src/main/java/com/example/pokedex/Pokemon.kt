package com.example.pokedex

import android.net.Uri

data class Pokemon(
    val name: String
    //val image: Uri
)