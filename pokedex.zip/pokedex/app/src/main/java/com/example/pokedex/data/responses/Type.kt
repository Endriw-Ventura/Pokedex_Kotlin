package com.example.pokedex.data.responses

data class Type(
    val slot: Int,
    val type: TypeX
)