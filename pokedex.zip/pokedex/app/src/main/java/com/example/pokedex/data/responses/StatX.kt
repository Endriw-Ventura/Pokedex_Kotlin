package com.example.pokedex.data.responses

data class StatX(
    val name: String,
    val url: String
)