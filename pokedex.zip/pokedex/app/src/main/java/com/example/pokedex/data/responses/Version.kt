package com.example.pokedex.data.responses

data class Version(
    val name: String,
    val url: String
)