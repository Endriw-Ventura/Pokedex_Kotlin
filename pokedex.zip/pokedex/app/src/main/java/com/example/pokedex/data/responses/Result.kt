package com.example.pokedex.data.responses

data class Result(
    val name: String,
    val url: String
)